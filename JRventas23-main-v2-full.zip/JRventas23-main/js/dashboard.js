// Módulo preparado para JR Ventas 2.0
